
from application import app, db
from application.models import User 

# Ensure the app context is active
with app.app_context():
    db.create_all()  # ✅ Create tables if they don't exist

    # Now add an item
    u1 = User(email_address = 'karrik@gmail.com', password_hash='nejkejjf', blood_group='A+', city='samana', gender='male', contact_number='9780240059')
    db.session.add(u1)
    db.session.commit()

    print("Item added successfully!")




